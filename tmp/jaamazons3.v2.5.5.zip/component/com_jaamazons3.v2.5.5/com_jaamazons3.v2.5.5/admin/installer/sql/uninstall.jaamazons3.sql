DROP TABLE IF EXISTS `#__jaamazons3_account`;
DROP TABLE IF EXISTS `#__jaamazons3_bucket`;
DROP TABLE IF EXISTS `#__jaamazons3_disabled`;
DROP TABLE IF EXISTS `#__jaamazons3_file`;
DROP TABLE IF EXISTS `#__jaamazons3_profile`;